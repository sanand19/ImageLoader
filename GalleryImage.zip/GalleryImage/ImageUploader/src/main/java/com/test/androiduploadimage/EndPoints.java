package com.test.androiduploadimage;

/**
 * Created by Sanjeev Anand on 11/15/2018
 */

public class EndPoints {
    private static final String ROOT_URL = "http://192.168.101.1/MyApi/Api.php?apicall=";
    public static final String UPLOAD_URL = ROOT_URL + "uploadpic";
    public static final String GET_PICS_URL = ROOT_URL + "getpics";
}
